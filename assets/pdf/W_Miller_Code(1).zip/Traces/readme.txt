This code can be run for any well-generated irreducible complex reflection group.

If the group is spetsial, it checks three things:
	1. the exponents of the Galois twists of the reflection representation are less than the Coxeter number
	2. the generic degrees evaluated at a root of unity are zero except for the exterior powers of Galois twists, where they are then (-1)^k
	3. the trace of a power of a zeta_h-regular element (where the lift is chosen so that c^h is the full twist) is given by a rational W-Catalan number

If the group is not spetsial, only properties 1 and 2 are checked.

Instructions:
	1. Make sure the location of the output file in traces.gap is correct
	2. Choose which group is being checked by updating the two lines at the beginning of traces.gap
	3. Run traces.gap
	4. Run tracesRegex.py
	5. Copy and run the output of tracesRegex.py in Mathematica

Mathematica will output True for each property that is checked successfully. 
For some of the groups, this may take a while; sometimes adding a TimeConstraint to FullSimplify can help speed things up.

#############################

traces.gap

	Gets all of the needed data from GAP3 and outputs to output.txt

#############################

tracesRegex.py

	Formats the output from traces.gap so that it can be copied into Mathematica. 
	Also determines the ``correct'' fake degrees and the indices of the exterior powers of Galois twists of the reflection representation for the infinite families.

#############################

traces.sage

	Used to compute the data in fakeDegrees.txt and twists.txt.

#############################

output.txt

	This is where traces.gap outputs the needed data.

#############################

fakeDegrees.txt

	Contains the ``correct'' fake degrees for the exceptional well-generated groups. 
	This data was computed using traces.sage.

#############################

twists.txt

	Contains the indices of the exterior powers of Galois twists of the reflection representation for the exceptional well-generated groups. 
	This data was computed using traces.sage

