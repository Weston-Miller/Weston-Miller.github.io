import math
from itertools import combinations

def partition(n,k):
	# partitions of n with all parts <= k
	if n == 0:
		return [[]]
	p = []
	for i in range(1,min(n,k)+1):
		for j in partition(n-i,min(k,i)):
			p.append([i] + j)
	return p

def multipartition(m,n):
	p = partition(n,n)
	mp = []
	for part in p:
		d = {i : part.count(i) for i in part}
		mp1 = []
		for i in sorted(d):
			components = []
			for j in combinations(range(m+d[i]-1),d[i]):
				comp = [[] for k in range(m)]
				index = 0
				for k in range(m+d[i]-1):
					if k in j:
						comp[index].append(i)
					else:
						index += 1
				components.append(comp)
			mp1.append(components)
		mp2 = mp1[0]
		for i in range(1,len(d.keys())):
			mp3 = []
			for j in mp2:
				for k in mp1[i]:
					mp4 = []
					for l in range(m):
						mp4.append(k[l] + j[l])
					mp3.append(mp4)
			mp2 = mp3
		mp = mp + mp2
	return mp

def dualMulti(mp):
	dmp = []
	for i in range(len(mp)):
		dmp.append(mp[-i])
	return dmp

def cycleMulti(mp):
	smp = []
	for i in range(len(mp)):
		smp.append(mp[i-1])
	return smp

def equivMulti(mp1, mp2):
	temp = mp1
	for i in range(len(mp1)):
		if temp == mp2:
			return True
		temp = cycleMulti(temp)
	return False

def numEquivMulti(mp):
	count = 0
	temp = mp
	for i in range(len(mp)):
		if temp == mp:
			count += 1
		temp = cycleMulti(temp)
	return len(mp) / count

def lexiMulti(mp):
	# determines the representative of the equivalence class of mp that is smallest in lexicographic order
	smallest = mp
	current = mp
	for i in range(len(mp)):
		for j in range(len(mp)):
			if len(smallest[j]) == 0:
				s = '0'
			else:
				s = ''.join(str(x) for x in smallest[j])

			if len(current[j]) == 0:
				c = '0'
			else:
				c = ''.join(str(x) for x in current[j])

			while len(s) < len(c):
				s += "0"
			while len(c) < len(s):
				c += "0"

			if int(c) < int(s):
				smallest = current
				break
			if int(s) < int(c):
				break
		current = cycleMulti(current)
	return smallest

out = ""
with open('output.txt') as f:
	for line in f:
		out += line

out = out.replace("\\\n", "")
out = out.replace("\n[", "[")
out = out.replace("Iq", "I q")

firstline = out.splitlines()[0]
fegLine = out[out.find("feg"):]
fegLine = fegLine[:fegLine.find(";")+1]
coxeterLine = out[out.find("h=")+2:]
coxeterLine = coxeterLine[:coxeterLine.find(";")]
coxeter = int(coxeterLine)
out = ''.join(out.splitlines(keepends=True)[1:])

if fegLine == "":
	print('error')
elif firstline.isnumeric():
	with open('fakeDegrees.txt') as f:
		for line in f:
			if line.startswith(firstline):
				out = out.replace(fegLine,"feg=List"+line[line.find('['):].rstrip()+";\n")
				break
	with open('twists.txt') as f:
		for line in f:
			if line.startswith(firstline):
				twists = line[line.find('[')+1:-2].rstrip()
				twists = twists.replace('[','{')
				twists = twists.replace(']','}')
				out+= "twists=List["+twists+"];\n"
				break
else:
	group = firstline.split(',')
	fegs = ''.join(fegLine[fegLine.find('[')+2:fegLine.find(']')].split()).split(',')
	m = int(group[0])
	n = int(group[2])
	mp = multipartition(m,n)
	newfegs = [0 for i in fegs]
	if group[0] == group[1]:
		chars = []
		for part in mp:
			if part == lexiMulti(part):
				chars.append(part)
		repeatedChars = []
		for equiv in chars:
			for i in range(int(m/numEquivMulti(equiv))):
				repeatedChars.append(equiv)
		for i in range(len(fegs)):
			dual = dualMulti(repeatedChars[i])
			for j in range(len(fegs)):
				if equivMulti(dual,repeatedChars[j]):
					newfegs[i] = fegs[j]
					break
		twists = []
		for p in range(coxeter):
			if math.gcd(p,coxeter) == 1:
				ptwist = []
				for k in range(n+1):
					part = [[]] * m
					part[0] = [n - k] if k < n else []
					part[p % m] = [1] * k if k > 0 else []
					for j in range(len(repeatedChars)):
						if equivMulti(part, repeatedChars[j]):
							ptwist.append(j+1)
							break
				twists.append(ptwist)
	else:
		for i in range(len(fegs)):
			newfegs[i] = fegs[mp.index(dualMulti(mp[i]))]
		twists = []
		for p in range(coxeter):
			if math.gcd(p,coxeter) == 1:
				ptwist = []
				for k in range(n+1):
					part = [[]] * m
					part[0] = [n - k] if k < n else []
					part[p % m] = [1] * k if k > 0 else []
					for j in range(len(mp)):
						if part == mp[j]:
							ptwist.append(j+1)
							break
				twists.append(ptwist)
	newfegsstr = "feg=List["
	for j in newfegs:
		newfegsstr += j + ","
	newfegsstr = newfegsstr[:-1] + "];\n"
	out = out.replace(fegLine,newfegsstr)
	out += "twists=List["
	for j in twists:
		out += "{"
		for k in j:
			out += str(k) + ","
		out = out[:-1]
		out += "},"
	out = out[:-1]
	out += "];\n"

i = 0
while i < len(out):
	if out[i] == 'E' and out[i+1] == 'R':
		j = i+1
		while out[j] != ')':
			j += 1
		j += 1
		out = out[:i] + "(Sqrt[" + out[i+3:j-1] + "])" + out[j:]
	i += 1

i = 0
while i < len(out):
	if out[i] == 'E' and out[i+1] == '(':
		j=i+2
		while out[j].isnumeric(): 
			j += 1
		out = out[:i] + "(E^(2 Pi I / " + out[i+2:j] + "))" + out[j+1:]
		i += 1
	i += 1

i=0
while i < len(out):
	if out[i] == 'E' and out[i+1].isnumeric():
		j=i+1
		while out[j].isnumeric(): 
			j += 1
		out = out[:i] + "(E^(2 Pi I / " + out[i+1:j] + "))" + out[j:]
		i += 1
	i += 1

print(out)
print("poincare=Times @@ (Function[x, (Sum[q^j, {j, 0, x - 1}])] /@ degrees);")
print("deg=top/schurs;")
print("fegZ=Function[x, RootReduce[Simplify[feg /. q -> E^(2 x Pi I/h)]]] /@ p;")
print("degZ=Function[x, Round[Chop[N[Limit[deg , q -> E^(2 x Pi I/h)]]]]] /@ p;")
print("catalan=Function[y, q^(-n (y + k h)) (1 - q)^n (Times @@ (Function[x, Sum[q^j, {j, 0, y + k h + Mod[y*(x - 1), h] - 1}]] /@ degrees))/poincare] /@ p;")
print("fegDegZsum=Table[(Plus @@ (Table[q^((-(p[[j]] + k h)/h) (a + contents[[i]])), {i, 1, Length[contents]}] feg degZ[[j]]))/(poincare), {j, Length[p]}];")
print("degFegZsum=Table[(Plus @@ (Table[q^((-(p[[j]] + k h)/h) (a + contents[[i]])), {i, 1, Length[contents]}] deg fegZ[[j]]))/(poincare), {j, Length[p]}];")
print("AllTrue[Flatten[Table[Flatten[Function[x, Table[Exponent[x, q], {i, 1, x /. q -> 1}]] /@ MonomialList[feg[[twists[[j]][[2]]]]]], {j, 1, Length[p]}]], # < h &]")
print("AllTrue[Table[Table[degZ[[i]][[twists[[i]][[j]]]], {j, 1, n + 1, 2}], {i, 1, Length[p]}], # == 1 &, 2] && AllTrue[Table[Table[degZ[[i]][[twists[[i]][[j]]]], {j, 2, n + 1, 2}], {i, 1,Length[p]}], # == -1 &, 2] && AllTrue[DeleteCases[degZ, 0, Infinity], Length[#] == n + 1 &]")
if (firstline.isnumeric() and int(firstline) in [4,6,8,14,23,24,25,26,27,28,29,30,32,33,34,35,36,37]) or not firstline.isnumeric():
	print("AllTrue[FullSimplify[RootReduce[Collect[catalan/degFegZsum,q]]], # == 1 &]")




